from StringIO import StringIO
import urllib
import xbmcaddon
import pyaes
import base64


url = "http://nunosilva.pw/encc"
salt=urllib.urlopen(url).read()
decryptor = pyaes.new(url, pyaes.MODE_CBC, IV='CASH KODI PLUGIN')
MainBase = decryptor.decrypt(base64.b64decode(salt)).strip()
addon = xbmcaddon.Addon('plugin.video.CasMart')


 
